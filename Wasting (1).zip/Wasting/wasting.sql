--1. Which countries had an increase in child wasting rate from 2000 to 2022?
SELECT Country, [2000], [2022]
FROM wasting
WHERE [2022] > [2000]  -- For increase


-- 2. What is the trend of child wasting rate for a specific country over the years? (e.g., Afghanistan)
SELECT Country, [2000], [2007], [2014], [2022]
FROM wasting
WHERE Country = 'Afghanistan';


-- 3.Which countries had a decrease in child wasting rate from 2000 to 2022?
SELECT Country, [2000], [2007], [2014], [2022]
FROM wasting
WHERE [2022] < [2000];


-- 4 Which countries have consistently had low child wasting rates across all years?
-- For this query, we first need to define "consistently low." As an example, we might consider a rate below a certain threshold (e.g., 5%) to be low.
SELECT Country, [2000], [2007], [2014], [2022]
FROM wasting
WHERE [2000] < 5 AND [2007] < 5 AND [2014] < 5 AND [2022] < 5;
