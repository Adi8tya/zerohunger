-- 1. Which countries had an increase in undernourishment rate from 2000 to 2022?

SELECT Country, [2000], [2022]
FROM undernourishment
WHERE [2022] > [2000];


-- 2. What is the trend of undernourishment rate for a specific country over the years? (e.g., Afghanistan)
SELECT Country, [2000], [2007], [2014], [2022]
FROM undernourishment
WHERE Country = 'Afghanistan';



-- 3. Which countries had a decrease in undernourishment rate from 2000 to 2022?
SELECT Country, [2000], [2022]
FROM Undernourishment
WHERE [2022] < [2000];


-- 4. Which countries have consistently had low undernourishment rates across all years?
SELECT Country, [2000], [2007], [2014], [2022]
FROM Undernourishment
WHERE [2000] < 5 AND [2007] < 5 AND [2014] < 5 AND [2022] < 5;
